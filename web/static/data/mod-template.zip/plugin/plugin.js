// Evaluated once per (machine, recipe) pair whenever the solver needs
// operating data for it. Must bind a global `plugin` object with an
// `evaluate(ctx)` function.
//
// ctx.machine.data and ctx.recipe.data mirror mod_data from mod.yml exactly
// as written — the host never interprets them, only passes them through.
// ctx.config is this mod's save-wide config (opaque, wizard-authored; {} if
// no wizard is set up for this mod).
//
// evaluate must return an array of variants. Exactly one of them — the
// "base" variant — must carry no items. rate is recipes per tick, given as
// an exact {num, den} fraction, never a float. Leaving outputs empty means
// "unchanged from the recipe catalog".
var plugin = {
  api_version: 1,
  evaluate: function (ctx) {
    var energyPerTick = ctx.recipe.data.energy_per_tick || 0;
    // Whatever the wizard below saved comes back here, unread by the host.
    var multiplier = (ctx.config && ctx.config.energy_multiplier) || 1;
    var costs = [];
    if (energyPerTick > 0) {
      costs.push({
        resource: "energy",
        amount: { num: energyPerTick * multiplier, den: 1 }
      });
    }
    return [{
      id: "base",
      label: "Base",
      rate: { num: 1, den: ctx.recipe.duration_ticks },
      costs: costs,
      outputs: [],
      items: [],
      valid: true
    }];
  },

  // ── Wizard (optional) ──────────────────────────────────────────────────
  // Drop this whole key and the mod simply gets no config button. Its
  // presence is detected structurally (plugin.wizard.mount must be a
  // function), so mentioning "wizard" in a comment costs nothing.
  //
  // Unlike evaluate(), which the host runs server-side in a JS VM with no
  // DOM, mount() runs in the user's browser. Everything the browser offers
  // is yours: elements, events, fetch, canvas.
  //
  // The host gives you only the modal frame — title, close button, backdrop
  // — plus the container you are handed. It never looks inside it.
  //
  // STYLING: the container carries the host's .wui-guest class, so a bare
  // <input>, <select>, <textarea> or <button> already looks like the rest of
  // the app without you naming a single class. Only reach for the package's
  // own classes when you want more than the defaults:
  //
  //   .field / .field-label   labelled form row
  //   .input / .select        explicit control styling (same look as bare)
  //   .radio-group + .radio-opt   segmented picker, 2-4 options
  //   .btn + .btn-primary     an action you want to emphasise
  //
  // TEXT: your strings are yours. The host translates its own chrome only,
  // and does not expose its translation bundles to plugins — ship your own
  // per-language strings if you need them.
  //
  // ctx.config     the saved config, {} on first open
  // ctx.saveConfig(obj) → Promise, persists it and re-runs the solve
  // ctx.close()    closes the modal; the host also closes on Esc/backdrop
  wizard: {
    mount: function (container, ctx) {
      var cfg = ctx.config || {};

      var label = document.createElement("label");
      label.className = "field";
      var caption = document.createElement("span");
      caption.className = "field-label";
      caption.textContent = "Energy multiplier";
      var input = document.createElement("input");
      input.type = "number";
      input.step = "0.1";
      input.min = "0";
      input.value = cfg.energy_multiplier || 1;
      label.append(caption, input);

      var save = document.createElement("button");
      save.type = "button";
      save.textContent = "Save";
      save.style.marginTop = "12px";
      save.addEventListener("click", function () {
        ctx.saveConfig({ energy_multiplier: parseFloat(input.value) || 1 })
          .then(function () { ctx.close(); })
          .catch(function () { });  // the host already reports the failure
      });

      container.append(label, save);
    },

    // Called before the modal goes away. Only needed if you attached
    // something outside the container — a timer, a document listener.
    unmount: function () { }
  }
};
