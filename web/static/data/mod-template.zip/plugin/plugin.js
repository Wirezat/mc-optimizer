// Evaluated once per (machine, recipe) pair whenever the solver needs
// operating data for it. Must bind a global `plugin` object with an
// `evaluate(ctx)` function.
//
// ctx.machine.data and ctx.recipe.data mirror mod_data from mod.yml exactly
// as written — the host never interprets them, only passes them through.
// ctx.config is this mod's config (opaque, wizard-authored; {} if none). It
// belongs to one production line: it is frozen into the line when it is
// confirmed, so changing it later never alters a line that already exists.
//
// evaluate must return an array of variants. Exactly one of them — the
// "base" variant — must carry no items. rate is recipes per tick, given as
// an exact {num, den} fraction, never a float. Leaving outputs empty means
// "unchanged from the recipe catalog"; if you do list outputs, the set must
// match the recipe's exactly, each ref as often as the recipe repeats it.
//
// LIMITS the host enforces. Breaking one is not a warning: the whole return
// value is rejected and your mod falls back to nominal recipe duration with
// no costs.
//
//   at most 256 variants per call
//   at most 64 entries in a variant's costs, outputs or items
//   at most 256 characters per string (ids, labels, refs)
//   every num, den and item count within +/- 2147483647
//   rate strictly positive; output probability within [0, 1]
//   evaluate has 2 seconds, and so does this file's top-level code
//
// DETERMINISM. Results are cached forever under (plugin version, machine
// mod_data, recipe mod_data, config), so the same inputs must always give the
// same answer. `Date` and `Math.random` are removed from the VM to keep you
// honest. The VM is also reused between calls: if you mutate a top-level
// variable, the next call sees it, and whatever it computed gets cached.
// Keep evaluate a pure function of ctx.
var plugin = {
  api_version: 1,
  evaluate: function (ctx) {
    var energyPerTick = ctx.recipe.data.energy_per_tick || 0;
    // Whatever the wizard below saved comes back here, unread by the host.
    var multiplier = (ctx.config && ctx.config.energy_multiplier) || 1;
    var costs = [];
    if (energyPerTick > 0) {
      costs.push({
        resource: "energy",
        amount: { num: energyPerTick * multiplier, den: 1 }
      });
    }
    return [{
      id: "base",
      label: "Base",
      rate: { num: 1, den: ctx.recipe.duration_ticks },
      costs: costs,
      outputs: [],
      items: [],
      valid: true
    }];
  },

  // ── Machines (optional) ────────────────────────────────────────────────
  // Drop this whole key if your mod has one machine per recipe. It matters
  // when several of your machines can run the SAME recipe — tiers, coil
  // variants, a multiblock standing in for a single block. The host models
  // those with machine_interfaces and then asks you which one to use.
  //
  // Unlike evaluate(), these run in the browser, and they cannot change what
  // a machine does — only WHICH machine a chain row uses. That choice reaches
  // the solver as an ordinary recipe override.
  machines: {
    // Extra columns in the chain table. cell() fills one per row.
    columns: [{ id: "tier", label: "Tier" }],

    // machine is { mod_id, machine_id }. Return "" for a column that is not
    // yours — the host asks every plugin for every column.
    cell: function (machine, columnID) {
      if (columnID !== "tier") return "";
      return machine.machine_id.indexOf("advanced_") === 0 ? "Advanced" : "Basic";
    },

    // candidates is [{ mod_id, machine_id }] — the machines that can run one
    // recipe. config is your own config, opaque to the host, which is why the
    // choice lives there and not in a control the host would have to
    // understand. Return an index into candidates, or -1 to leave the row as
    // the solver picked it.
    resolve: function (candidates, config) {
      var want = (config && config.tier) || "basic";
      for (var i = 0; i < candidates.length; i++) {
        var isAdvanced = candidates[i].machine_id.indexOf("advanced_") === 0;
        if ((want === "advanced") === isAdvanced) return i;
      }
      return -1;
    }
  },

  // ── Wizard (optional) ──────────────────────────────────────────────────
  // Drop this whole key and the mod simply gets no config button. Its
  // presence is detected structurally (plugin.wizard.mount must be a
  // function), so mentioning "wizard" in a comment costs nothing.
  //
  // Unlike evaluate(), which the host runs server-side in a JS VM with no
  // DOM, mount() runs in the user's browser. Everything the browser offers
  // is yours: elements, events, fetch, canvas.
  //
  // The host gives you only the modal frame — title, close button, backdrop
  // — plus the container you are handed. It never looks inside it.
  //
  // STYLING: the container carries the host's .wui-guest class, so a bare
  // <input>, <select>, <textarea> or <button> already looks like the rest of
  // the app without you naming a single class. Only reach for the package's
  // own classes when you want more than the defaults:
  //
  //   .field / .field-label   labelled form row
  //   .input / .select        explicit control styling (same look as bare)
  //   .radio-group + .radio-opt   segmented picker, 2-4 options
  //   .btn + .btn-primary     an action you want to emphasise
  //
  // TEXT: your strings are yours. The host translates its own chrome only,
  // and does not expose its translation bundles to plugins — ship your own
  // per-language strings if you need them.
  //
  // ctx.config     the saved config, {} on first open
  // ctx.saveConfig(obj) → Promise, persists it and re-runs the solve
  // ctx.close()    closes the modal; the host also closes on Esc/backdrop
  wizard: {
    mount: function (container, ctx) {
      var cfg = ctx.config || {};

      var label = document.createElement("label");
      label.className = "field";
      var caption = document.createElement("span");
      caption.className = "field-label";
      caption.textContent = "Energy multiplier";
      var input = document.createElement("input");
      input.type = "number";
      input.step = "0.1";
      input.min = "0";
      input.value = cfg.energy_multiplier || 1;
      label.append(caption, input);

      var tierLabel = document.createElement("label");
      tierLabel.className = "field";
      var tierCaption = document.createElement("span");
      tierCaption.className = "field-label";
      tierCaption.textContent = "Machine tier";
      var tier = document.createElement("select");
      ["basic", "advanced"].forEach(function (id) {
        var opt = document.createElement("option");
        opt.value = id;
        opt.textContent = id === "basic" ? "Basic" : "Advanced";
        if (id === (cfg.tier || "basic")) opt.selected = true;
        tier.appendChild(opt);
      });
      tierLabel.append(tierCaption, tier);

      var save = document.createElement("button");
      save.type = "button";
      save.textContent = "Save";
      save.style.marginTop = "12px";
      save.addEventListener("click", function () {
        ctx.saveConfig({
          tier: tier.value,
          energy_multiplier: parseFloat(input.value) || 1
        })
          .then(function () { ctx.close(); })
          .catch(function () { });  // the host already reports the failure
      });

      container.append(tierLabel, label, save);
    },

    // Called before the modal goes away. Only needed if you attached
    // something outside the container — a timer, a document listener.
    unmount: function () { }
  }
};
