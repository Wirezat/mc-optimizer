// Evaluated once per (machine, recipe) pair. Must bind a global `plugin`
// object with an `evaluate(ctx)` function.
//
// ctx.machine.data and ctx.recipe.data mirror mod_data from mod.yml exactly
// as written — the host never interprets them, only passes them through.
// ctx.recipe.machine_mod / machine_id name the machine the recipe is DEFINED
// for, which is not the machine you are asked about when yours reaches the
// recipe through machine_interfaces — that is how a furnace replacement tells
// a smelting recipe from a blasting one.
// ctx.config is this mod's config (opaque, wizard-authored; {} if none). It
// belongs to one production line: it is frozen into the line when it is
// confirmed, so changing it later never alters a line that already exists.
//
// evaluate returns an array of variants — the CELLS your machine contributes
// to a matrix the host assembles across every mod that can run this recipe.
// The host picks exactly one cell.
//
// rate is recipes per tick as an exact {num, den} fraction, never a float.
// Leaving outputs empty means "unchanged from the recipe catalog"; if you do
// list outputs, the set must match the recipe's exactly. inputs add
// consumption the recipe does not have ("#tag", "~fluid" or "mod:item"); the
// host carries them through but does not branch the chain into them yet.
//
// HOW THE HOST PICKS, so you know what your numbers compete on:
//
//   1  valid == false                      dropped
//   2  fewest machines                     ceil(demand / rate)
//   3  highest utilisation                 the smallest cell that still fits
//   4  most byproduct                      whole machines it saves elsewhere
//   5  lowest consumption, per resource    only cells sharing a resource set
//   6  mod already used in this chain      one mod beats five
//   7  lowest rank                         YOUR order, within your plugin only
//   8  (mod, machine, variant id)          deterministic remainder
//
// `rank` is the only lever that is purely yours — for preferences the host
// cannot see, such as one coil being cheaper to build than another.
//
// LIMITS the host enforces. Breaking one is not a warning: the whole return
// value is rejected and your mod falls back to nominal recipe duration with
// no costs.
//
//   at most 256 variants per call, 64 entries in one variant's lists
//   at most 256 characters per string (ids, labels, refs)
//   every num, den and item count within +/- 2147483647
//   rate strictly positive; output probability within [0, 1]
//   at most one variant with no items — zero is fine when every cell needs
//     something installed (a blasting augment, say)
//   evaluate has 2 seconds, and so does this file's top-level code
//
// EMIT FEWER CELLS. Drop any cell another of yours beats on both speed and
// cost — the host can never have a reason to pick it. Tiers crossed with
// upgrade counts reach thousands of combinations fast.
//
// VARIANT IDS ARE PERMANENT. machine_groups stores them and resolves them
// again on every later page load, so a rename costs every existing production
// line its variant. Build ids from a scheme, never from a display label.
//
// DETERMINISM. Results are cached forever under (plugin version, machine
// mod_data, recipe mod_data, config) — note what is NOT in that key: the
// demanded rate. You return the whole table and the host picks from it.
// `Date` and `Math.random` are removed from the VM, which is also reused
// between calls: keep evaluate a pure function of ctx.
var plugin = {
  api_version: 1,

  evaluate: function (ctx) {
    var m = ctx.machine.data || {};
    var cfg = ctx.config || {};
    var duration = Math.max(ctx.recipe.duration_ticks, 1);

    // Anything above what the player has built is reported as one invalid
    // variant; the host drops the machine from the matrix.
    var TIERS = ["basic", "advanced"];
    var tier = TIERS.indexOf(m.tier || "basic");
    var maxTier = TIERS.indexOf(cfg.max_tier || "basic");
    if (tier < 0 || maxTier < 0 || tier > maxTier) {
      return [{
        id: "base", label: "", rate: { num: 1, den: duration },
        costs: [], inputs: [], outputs: [], items: [], valid: false
      }];
    }

    // Which vanilla machine the recipe belongs to. Skip this if your mod
    // ships its own recipes.
    var base = (ctx.recipe.machine_mod || "") + ":" + (ctx.recipe.machine_id || "");
    var needsAugment = base === "minecraft:blast_furnace" ? "blasting"
                     : base === "minecraft:smoker" ? "smoking" : null;

    var energyPerTick = ctx.recipe.data.energy_per_tick || 0;
    var speedUnlocked = cfg.speed_unlocked !== false;

    var out = [];
    var points = [{ id: "plain", label: "", ticks: duration, factor: 1, rank: 0 }];
    if (speedUnlocked) {
      points.push({ id: "speed", label: "Speed", ticks: Math.max(1, Math.floor(duration / 2)), factor: 2, rank: 1 });
    }

    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      // A "faster" point that did not get faster is dominated.
      if (p.id !== "plain" && p.ticks === duration) continue;

      var items = [];
      if (needsAugment) items.push({ ref: "example:augment_" + needsAugment, count: 1 });
      if (p.id !== "plain") items.push({ ref: "example:speed_upgrade", count: 1 });

      var costs = [];
      if (energyPerTick > 0) {
        costs.push({ resource: "energy", amount: { num: energyPerTick * p.factor, den: 1 } });
      }

      out.push({
        id: (needsAugment ? needsAugment + "_" : "") + p.id,
        label: [needsAugment, p.label].filter(Boolean).join(" + "),
        rate: { num: 1, den: p.ticks },
        costs: costs,
        inputs: [],  // consumption the recipe does not list
        outputs: [], // empty means catalog amounts unchanged
        items: items,
        valid: true,
        // Lower is preferred. Compared only against your own cells.
        rank: tier * 10 + p.rank
      });
    }
    return out;
  },

  // ── Machines (optional) ────────────────────────────────────────────────
  // Display only; drop the key if you have nothing to show. There is no
  // `resolve` any more: the solver picks the machine once it knows how much
  // the chain needs. Make your cells win, or let the player pin the row.
  machines: {
    // Extra chain-table columns. Pick an id nobody else will: the host
    // flattens columns across mods.
    columns: [{ id: "example_tier", label: "Tier" }],

    // Return "" for a column that is not yours: every plugin is asked for
    // every column.
    cell: function (machine, columnID) {
      if (columnID !== "example_tier") return "";
      return machine.machine_id.indexOf("advanced_") === 0 ? "Advanced" : "Basic";
    }
  },

  // ── Wizard (optional) ──────────────────────────────────────────────────
  // Drop the key and the mod gets no config button; its presence is detected
  // structurally (plugin.wizard.mount must be a function).
  //
  // Ask only for what the player knows and you cannot derive: what they have
  // built, which supply their line runs on. Never ask which operating point to
  // use — every option here is one the solver can no longer optimise.
  //
  // Unlike evaluate(), mount() runs in the user's browser, with everything the
  // browser offers.
  //
  // STYLING: the container carries .wui-guest, so a bare <input>, <select>
  // or <button> already looks like the rest of the app. Named classes when
  // you want more: .field / .field-label / .field-caption, .input, .select,
  // .radio-group + .radio-opt, .btn + .btn-primary, .form-actions.
  //
  // TEXT: your strings are yours; the host translates its own chrome only.
  //
  // ctx.config      the saved config, {} on first open
  // ctx.saveConfig(obj) → Promise, persists it and re-runs the solve
  // ctx.close()     closes the modal; the host also closes on Esc/backdrop
  wizard: {
    mount: function (container, ctx) {
      var cfg = ctx.config || {};

      var tierLabel = document.createElement("label");
      tierLabel.className = "field";
      var tierCaption = document.createElement("span");
      tierCaption.className = "field-label";
      tierCaption.textContent = "Highest machine built";
      var tier = document.createElement("select");
      tier.className = "input";
      ["basic", "advanced"].forEach(function (id) {
        var opt = document.createElement("option");
        opt.value = id;
        opt.textContent = id === "basic" ? "Basic" : "Advanced";
        if (id === (cfg.max_tier || "basic")) opt.selected = true;
        tier.appendChild(opt);
      });
      var hint = document.createElement("span");
      hint.className = "field-caption";
      hint.textContent = "Everything up to this counts as available; the solver picks the smallest that fits.";
      tierLabel.append(tierCaption, tier, hint);

      var save = document.createElement("button");
      save.type = "button";
      save.className = "btn btn-primary";
      save.textContent = "Save";
      save.addEventListener("click", function () {
        ctx.saveConfig({ max_tier: tier.value })
          .then(function () { ctx.close(); })
          .catch(function () { });  // the host already reports the failure
      });
      var actions = document.createElement("div");
      actions.className = "form-actions";
      actions.appendChild(save);

      container.append(tierLabel, actions);
    },

    // Only needed if you attached something outside the container.
    unmount: function () { }
  }
};
